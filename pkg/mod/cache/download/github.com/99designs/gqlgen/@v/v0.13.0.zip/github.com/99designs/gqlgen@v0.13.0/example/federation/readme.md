### Federation

[Read the docs](https://gqlgen.com/recipes/federation/)
