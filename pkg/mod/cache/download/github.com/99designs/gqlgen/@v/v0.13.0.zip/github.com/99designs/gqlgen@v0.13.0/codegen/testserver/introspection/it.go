package introspection

type It struct {
	ID string
}
