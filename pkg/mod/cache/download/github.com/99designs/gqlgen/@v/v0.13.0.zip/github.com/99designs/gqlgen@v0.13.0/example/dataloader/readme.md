### dataloader

This example uses [dataloaden](https://github.com/vektah/dataloaden) to avoiding n+1 queries.  


There is also [nicksrandall/dataloader](https://github.com/nicksrandall/dataloader) if you wanted to avoid 
doing more codegeneration. 
