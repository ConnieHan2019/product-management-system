package testserver

type RecursiveInputSlice struct {
	Self []RecursiveInputSlice
}
