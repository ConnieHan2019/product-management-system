package external

type ObjectID int
