### examples

 - todo: A simple todo checklist. A good place to get the basics down
 - starwars: A starwars movie database. It has examples of advanced graphql features
 - dataloader: How to avoid n+1 database query problems 
