### starwars example

This server demonstrates a few advanced features of graphql:
 - connections
 - unions
 - interfaces
 - enums

to run this server
```bash
go run ./example/starwars/server/server.go
```

and open http://localhost:8080 in your browser
