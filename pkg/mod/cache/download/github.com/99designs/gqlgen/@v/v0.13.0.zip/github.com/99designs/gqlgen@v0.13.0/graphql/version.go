package graphql

const Version = "v0.13.0"
