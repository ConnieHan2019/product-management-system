package graphql

type Query struct{}

type Mutation struct{}

type Subscription struct{}
