### What happened?

### What did you expect?

### Minimal graphql.schema and models to reproduce

### versions
 - `gqlgen version`? 
 - `go version`?
 - dep or go modules?
