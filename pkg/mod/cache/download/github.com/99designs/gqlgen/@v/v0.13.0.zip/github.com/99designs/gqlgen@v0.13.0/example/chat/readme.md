### chat app

Example app using subscriptions to build a chat room.

to run this server
```bash
go run ./example/chat/server/server.go
```

to run the react app
```bash
cd ./example/chat
npm install 
npm run start
```
