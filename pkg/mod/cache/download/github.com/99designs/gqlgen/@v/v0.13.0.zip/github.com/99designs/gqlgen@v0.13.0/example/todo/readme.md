### todo app

This is the simplest example of a graphql server.

to run this server
```bash
go run ./example/todo/server/server.go
```

and open http://localhost:8081 in your browser
